$(document).ready(function() {
    $('#example').DataTable({
        dom: 'Bfrtip',

        buttons: [{
                extend: 'csvHtml5',
                text: 'Download CSV',
                className: 'btn btn-primary'
            },

        ]
    });
});