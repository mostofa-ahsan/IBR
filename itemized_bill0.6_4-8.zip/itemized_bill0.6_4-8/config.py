clean_searchable_pdf_lines = None
filename= None
total_cost_1 = None 
search_df_1 = None
timestr = None
csv_name = None