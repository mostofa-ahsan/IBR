import re
from difflib import get_close_matches
from logging import exception
from flask import Flask, render_template, request, redirect, flash, session
from pdf_to_text import pdf_to_image, image_to_pdf, PDF_searchable_lines, Search_in_PDF
from werkzeug.utils import secure_filename
import os
import config

# create and configure the app
app = Flask(__name__, instance_relative_config=True)
app.config.from_mapping(
    SECRET_KEY='dev',
)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload')
def upload():
    return render_template('upload.html')


@app.route('/uploader', methods=['POST'])
def uploadPDF():
    single_file = True
    filename = request.form.get('file')

    if request.method == 'POST':
        # upload_loc = os.environ.get("upload_loc")
        upload_loc= 'C:/Users/mkahs/Repository/IBR-main/itemized_bill0.6_updated/itemized_bill0.6_updated/static/assets/pdf_uploads/'
        all_files = request.files.getlist('file')
        single_file = False if len(all_files) > 1 else True
        if not all_files and filename:
            filename = get_close_matches(filename, os.listdir(upload_loc))[0]
            all_files = [filename]
        for f in all_files:
            try:
                config.filename = f.filename if not filename else f
                if not filename:
                    f.save(os.path.join(upload_loc, secure_filename(config.filename)))
                processed_image_loc, pdf_name = pdf_to_image(os.path.join(upload_loc, secure_filename(config.filename)))
                print(processed_image_loc)
                print(pdf_name)
                ########### IMAGE TO PDF PROCESSING #######################
                processed_pdf = image_to_pdf(processed_image_loc, pdf_name)
                print(processed_pdf)
                print(pdf_name)
                ########### PROCESSED PDF TO SEARCHABLE PDF #######################
                clean_searchable_pdf_lines, timestr = PDF_searchable_lines(pdf_name)
                # breakpoint()
                config.timestr = timestr
                config.clean_searchable_pdf_lines = clean_searchable_pdf_lines
                flash(f"{config.filename} Uploaded successfully!", 'success')
            except Exception as e:
                flash(e, 'danger')
        return render_template('upload.html', upload_status='Done', single_file=single_file)

        # return render_template('upload.html', upload_status='Failed')




@app.route('/search', methods=['POST'])
def search_term():
    if request.method == 'POST':
        search_word = request.form['search']
        cost_list_1, total_cost_1, search_df_1 = Search_in_PDF(search_word)
        config.total_cost_1 = total_cost_1
        config.search_df_1 = search_df_1
        # breakpoint()

        # upload_loc = os.environ.get('upload_loc')
        upload_loc= 'C:/Users/mkahs/Repository/IBR-main/itemized_bill0.6_updated/itemized_bill0.6_updated/static/assets/pdf_uploads/'
        files_list = os.listdir(upload_loc)
        filename = get_close_matches(config.filename, files_list)[0]
        filename = 'assets/pdf_uploads/' + filename

        config.csv_name = config.filename + search_word + config.timestr
    return render_template('view_bill.html', csv_name=config.csv_name, filename=config.filename,
                           search_df_1=config.search_df_1, total_cost_1=config.total_cost_1, timestr=config.timestr, file_path=filename)


@app.route('/search_pdf', methods=['GET', 'POST'])
def search_pdf():
    res = []
    if request.method == 'POST':
        search_word = request.form['search']
        # output_loc = os.environ.get('output_loc')
        output_loc = "C:/Users/mkahs/Repository/IBR-main/itemized_bill0.6_updated/itemized_bill0.6_updated/static/assets/searchable_pdf/"
        files_list = os.listdir(output_loc)
        res = [x for x in files_list if re.search(search_word, x)]

    return render_template('search.html', res=res)


@app.route('/viewbill')
def viewBill():
    return render_template('view_bill.html', csv_name=config.csv_name, filename=config.filename,
                           search_df_1=config.search_df_1, total_cost_1=config.total_cost_1, timestr=config.timestr)
