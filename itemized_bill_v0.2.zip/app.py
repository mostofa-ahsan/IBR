

from logging import exception
from flask import Flask, render_template,request,redirect,flash
from pdf_to_text import pdf_to_image,image_to_pdf,PDF_searchable_lines
from werkzeug.utils import secure_filename
import os
# create and configure the app
app = Flask(__name__, instance_relative_config=True)
app.config.from_mapping(
    SECRET_KEY='dev',
)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload')
def upload():
    return render_template('upload.html')

@app.route('/uploader',methods=['POST'])
def uploadPDF():
    if request.method == 'POST':
        breakpoint()
        try:
            f = request.files['file']
            upload_loc = os.environ.get("upload_loc") 
            f.save(os.path.join(upload_loc,secure_filename(f.filename)))
            processed_image_loc, pdf_name = pdf_to_image(secure_filename(f.filename))
            print(processed_image_loc)
            print(pdf_name)
            ########### IMAGE TO PDF PROCESSING #######################
            processed_pdf = image_to_pdf(processed_image_loc, pdf_name)
            print(processed_pdf)
            ########### PROCESSED PDF TO SEARCHABLE PDF #######################
            clean_searchable_pdf_lines = PDF_searchable_lines(pdf_name )
            # clean_searchable_pdf_lines= PDF_searchable_lines(s)
            flash('file uploaded successfully')
            return redirect('/upload')  
        except Exception as e:
            return e


@app.route('/viewbill')
def viewBill():
    return render_template('view_bill.html')