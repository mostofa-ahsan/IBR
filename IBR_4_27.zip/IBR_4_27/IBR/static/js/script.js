$(document).ready(function() {
    $('#example').DataTable({
        dom: 'Bfrtip',
        buttons: [{
                extend: 'csvHtml5',
                text: 'Download CSV',
                title: $('#csv_name').val(),
                className: 'btn btn-primary'
            },


        ],
        "oLanguage": {

            "sSearch": "Search in Result:"

        }
    });
});

function loading() {
    $("#loading").show();
}