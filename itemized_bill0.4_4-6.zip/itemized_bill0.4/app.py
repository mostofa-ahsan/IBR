
from logging import exception
from flask import Flask, render_template,request,redirect,flash,session
from pdf_to_text import pdf_to_image,image_to_pdf,PDF_searchable_lines,Search_in_PDF
from werkzeug.utils import secure_filename
import os
import config
# create and configure the app
app = Flask(__name__, instance_relative_config=True)
app.config.from_mapping(
    SECRET_KEY='dev',
)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload')
def upload():
    return render_template('upload.html')

@app.route('/uploader',methods=['POST'])
def uploadPDF():
    if request.method == 'POST':
        try:
            f = request.files['file']
            # upload_loc = os.environ.get("upload_loc") 
            upload_loc= 'C:/Users/mkahs/Repository/IBR-main/IBR-main/itemized_bill0.4/static/assets/pdf_uploads/'
            config.filename = f.filename
            f.save(os.path.join(upload_loc,secure_filename(f.filename)))
            processed_image_loc, pdf_name = pdf_to_image(os.path.join(upload_loc,secure_filename(f.filename)))
            print(processed_image_loc)
            print(pdf_name)
            ########### IMAGE TO PDF PROCESSING #######################
            processed_pdf = image_to_pdf(processed_image_loc, pdf_name)
            print(processed_pdf)
            print(pdf_name)
            ########### PROCESSED PDF TO SEARCHABLE PDF #######################
            clean_searchable_pdf_lines , timestr= PDF_searchable_lines(pdf_name)
            config.clean_searchable_pdf_lines = clean_searchable_pdf_lines
            flash("File Uploaded successfully!", 'success')
            return render_template('upload.html',upload_status='Done')  
        except Exception as e:
            flash(e, 'danger')
            return render_template('upload.html',upload_status='Failed') 


@app.route('/search',methods=['POST'])
def search_term():
    if request.method == 'POST':
        search_word = request.form['search']
        cost_list_1, total_cost_1, search_df_1 = Search_in_PDF(search_word)
        config.total_cost_1 = total_cost_1
        config.search_df_1 = search_df_1
    return render_template('view_bill.html',filename= config.filename,search_df_1 = config.search_df_1,total_cost_1=config.total_cost_1)    

@app.route('/viewbill')
def viewBill():
    return render_template('view_bill.html',filename= config.filename,search_df_1 = config.search_df_1,total_cost_1=config.total_cost_1)